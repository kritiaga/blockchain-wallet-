
Please include your service-my-wallet-v3 and NodeJS version numbers when submitting an issue.
Example: *Service v0.18.0, Node v0.12.5*
